import { createApp } from 'vue'
import { createPinia } from 'pinia';
import App from './App.vue'
import router from './router'
import piniaPluginPersistedstate from 'pinia-plugin-persistedstate';

import { useKakao } from 'vue3-kakao-maps/@utils'
import { VueNaverMaps } from 'vue-naver-maps'
import { createNaverMap } from 'vue3-naver-maps'

import 'bootstrap'
import 'bootstrap/dist/css/bootstrap.min.css'

const app = createApp(App)
const pinia = createPinia();

pinia.use(piniaPluginPersistedstate);

app.use(createNaverMap, {
  clientId: 'e0in5sxvwv',
  category: 'ncp',
  subModules: [],
})

app.use(VueNaverMaps, {
  clientId : 'e0in5sxvwv',
  useGovAPI: false, //공공 클라우드 API 사용 (선택)
  subModules:'' // 서브모듈 (선택)
})

useKakao('01f1b08e0b51a6a36084c1c22b333eaf')
app.use(pinia);
app.use(router);

app.mount('#app')