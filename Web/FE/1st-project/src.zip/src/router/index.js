import { createRouter, createWebHistory } from "vue-router";
import UserLogin from "@/components/user/UserLogin.vue";
import SignUp from "@/components/user/SignUp.vue";
import HomeView from "@/components/HomeView.vue";

import BuildingDetail from "@/components/building/BuildingDetail.vue";
import SelectBuilding from "@/components/building/SelectBuilding.vue";

import FireBuildingSelect from "@/components/fire/FireBuildingSelect.vue";

import RobotDetail from "@/components/RobotDetail.vue";
import RobotRegist from "@/components/RobotRegist.vue";
import MapTest from "@/components/MapTest.vue";

const routes = [
  {
    path: '/',
    name: 'home',
    component: HomeView,
  },
  {
    path: '/login',
    name: 'login',
    component: UserLogin,
    meta: { hideNavbar: true, loginBackground: true }
  },
  {
    path: '/signup',
    name: 'signup',
    component: SignUp,
  },
  {
    path: '/regist',
    name: 'regist',
    component: RobotRegist, 
  },
  {
    path: '/building',
    name: 'building',
    component: SelectBuilding,
  },
  {
    path: '/building/:id',
    name: 'building-detail',
    component: BuildingDetail,
    props: true
  },
  {
    path: '/robot-detail',
    name: 'robot-detail',
    component: RobotDetail
  },
  {
    path: '/fire-building',
    name: 'fire-building-select',
    component: FireBuildingSelect
  },  
  // {
  //   path: '/openvidu',
  //   name: 'openvidu',
  //   component: ViduStart
  // },
  {
    path: '/test',
    name: 'test',
    component: MapTest
  },  
  // {
  //   path: '/robot-detail',
  //   name: 'robot-detail',
  //   component: RobotDetail
  // },  
  // {
  //   path: '/robot-detail',
  //   name: 'robot-detail',
  //   component: RobotDetail
  // },
];

// var express = require('express');
// var Router = express.Router();

// Router.get('/fireissues/fire-popup/', function(req, res, next) {
//   res.setHeader("content-Type", "text/event-stream")
//   res.setHeader('Cache-Control', 'no-cache')

//   res.flushHeaders()
//   console.log(next)

//   let interval = setInterval(function() {
//     res.write(`data: ${new Date()}\n\n`)
//   }, 1000);

//   res.on('close', () => {
//     clearInterval(interval);
//     res.end
//   })
// })

// module.exports = Router;

const router = createRouter({
  history: createWebHistory(),
  routes,
  scrollBehavior(to, from, savedPosition) {
    if (savedPosition) {
      return savedPosition;
    } else {
      return { top: 0 };
    }
  }
});

export default router;