<template>
  <div :class="{ 'login-background' : isLoginBackground }" id="app">
    <NavbarComponent v-if="showNavbar" />

    <router-view @route-changed="onRouteChange"></router-view>
    <router-link to="/login">login</router-link>
    <br>
    <router-link to="/regist">regist</router-link>
    <br>
    <router-link to="/building">building</router-link>
    <br>
    <router-link to="/detail">detail</router-link>
    <br>
    <router-link to="/robot-detail">robot-detail</router-link>
    <br>
    <router-link to="/fire-building">fire-building</router-link>
    <br>
    <router-link to="/test">maptest</router-link>
    <br>
    <router-link to="/signup">signup</router-link>
  </div>
  <div id="logs">

  </div>
</template>


<script>
// import { computed, onUnmounted, watch } from 'vue';
import { computed, watch } from 'vue';
import { useRoute } from 'vue-router';
import NavbarComponent from './components/NavbarComponent.vue';
// import { EventSourcePolyfill } from "event-source-polyfill";

export default {
  name: 'App',
  components: {
    NavbarComponent,
  },
  setup() {
    const route = useRoute();
    const showNavbar = computed(() => !route.meta.hideNavbar);
    const isLoginBackground = computed(() => route.meta.loginBackground);
    // const EventSource = EventSourcePolyfill || NativeEventSource

    // SSE 연결 설정
    // const token = 'token ad96fb39f984f47657d5c35a81e2ebe495e5bcbb';
    // const source = new EventSource(`http://3.36.55.201:8000/fireissues/fire-popup/?token=${token}`);
    // const source = new EventSource(
    //   'http://3.36.55.201:8000/fireissues/fire-popup/',
    //   {
    //     headers: {
    //       Authorization: 'token ad96fb39f984f47657d5c35a81e2ebe495e5bcbb'
    //     },
    //     withCredentials: true
    //   }
    // )
  //   const source = new EventSourcePolyfill('http://3.36.55.201:8000/fireissues/fire-popup/', { headers: { 'Authorization': 'token ad96fb39f984f47657d5c35a81e2ebe495e5bcbb' } });
    
  //   source.onmessage = function(e) {
  //     let p = document.createElement('p');
  //     p.innertext = e.data;  

  //     document.getElementById('sse-messages').appendChild(p);
  //   }

  //   function isUserLoggedIn() {
  //     // 세션 또는 쿠키를 확인하여 로그인 상태를 판별하는 함수
  //     return document.cookie.includes('sessionid');
  //   }

  //   document.addEventListener('DOMContentLoaded', () => {
  // // 사용자가 로그인한 상태에서만 SSE 연결 설정
  //   if (isUserLoggedIn()) { // isUserLoggedIn은 사용자의 로그인 상태를 확인하는 함수
  //     const source = new EventSource('/fireissues/fire-popup/');

  //     source.onopen = () => {
  //       console.log('SSE connection established');
  //     };

  //     source.onmessage = (event) => {
  //       console.log('New message: ' + event.data);
  //       // 데이터가 JSON 형식이라고 가정하고 파싱
  //       try {
  //         console.log(event.data);
  //         const data = JSON.parse(event.data);
  //         this.alert.push(data)
  //         console.log('Parsed data:', data);
  //         // 예를 들어 message를 처리하는 부분
  //         // message.value = data.message;
  //       } catch (error) {
  //         console.log('Failed to parse message data:', error);
  //       }
  //     };

  //     source.onerror = (error) => {
  //       console.log('SSE error:', error);
  //       source.close();  // 에러 발생 시 연결 종료
  //     };
  //     }
  //   })

  //   // 컴포넌트 언마운트 시 SSE 연결 종료
  //   onUnmounted(() => {
  //     source.close();
  //   });

    watch(isLoginBackground, (value) => {
      if (value) {
        document.body.style.backgroundColor = 'rgba(255, 255, 255, 0.49)';
      } else {
        document.body.style.backgroundColor = 'white';
      }
    }, { immediate: true });

    return { showNavbar, isLoginBackground };
  }
};

</script>

<style>
  body {
    font-family: 'Inter', sans-serif;
    justify-content: center;
    align-items: center;
    align-content: center;
    height: 100%;
    margin: 0;
    padding: 0;
  }

  .login-background {
    background-color: rgba(194, 25, 26, 0.49);
  }
</style>