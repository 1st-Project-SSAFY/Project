import { defineStore } from 'pinia';
import axios from 'axios';
import router from '@/router';
import { ref } from 'vue';

export const useUserStore = defineStore('user', () => {
  const API_URL = 'http://3.36.55.201:8000/';
  const token = ref('');

  const checkFireFighter = (payload, refs) => {
    const { name, number } = payload;
    const { duty, firestation, errorMsg, isVerified } = refs;

    duty.value = '';
    firestation.value = '';
    errorMsg.value = '';
    isVerified.value = false;

    axios({
      method: 'get',
      url: API_URL + 'accounts/signup/',
      params: {
        name, number
      },
    }).then((response) => {
      console.log('정보조회 완료');
      if (response.data.data){
        duty.value = response.data.data.duty === 0 ? '현장직' : '관리직';
        firestation.value = response.data.data.firestation;
        isVerified.value = true;
      }
      else {
        errorMsg.value = response.data.data.error
      }
    }).catch((err) => {
      if (err.response.data.error === '이미 가입된 사용자입니다.') {
        errorMsg.value = '이미 가입된 사용자입니다';
      } else {
        console.log(err.response.data)
        errorMsg.value = '소방관 정보를 찾을 수 없습니다. 입력하신 정보를 확인해주세요';
      }
    });
  };

  const signUp = (payload) => {
    const { name, number } = payload;

    axios({
      method: 'post',
      url: API_URL + 'accounts/signup/',
      data: {
        name, number
      },
    }).then(() => {
      console.log('회원가입 완료')
      router.push({ name: 'login'})
    }).catch((err) =>{
      console.log(err)
    })
  }

  const logIn = (payload) => {
    const { username, password } = payload;
    const duty = ref('');

    axios({
      method: 'POST',
      url: API_URL + 'accounts/login/',
      data: {
        username, 
        password
      }
    }).then((res) => {
      console.log('로그인 완료')
      token.value = res.data.key
      duty.value = res.data.duty

      if (duty.value === 1) {
        router.push('/building')
      } else {
        router.push('/fire-building')
      }
    }).catch((err) => {
      console.log('로그인 불가')
      console.log(err)
      password.value = ''
      alert('Error: ' + err.message)
    })
  }

  const logOut = async() => {
    axios({
      method: 'post',
      url: API_URL + 'logout/',
      headers: {
        Authorization: `Token ${token.value}`
      },
      
    }).then(() => {
      console.log('로그아웃')
      token.value = '';
      router.push('/login')
    }).catch((err) => {
      console.log(this.Authorization)
      console.log(err)
    })
  }  

  return { API_URL, checkFireFighter, signUp, logIn, logOut, token };
}, {
  persist: true
});