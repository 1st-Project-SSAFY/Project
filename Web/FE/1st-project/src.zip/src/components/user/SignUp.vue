<template>
  <div class="container">
    <div class="signup-header">
      <h1 class="signup-title">신규 소방관 등록</h1>
      <h3 class="signup-subtitle">신규로 등록하기 위한 정보를 입력해주세요</h3>
    </div>
    <form class="signup-form" @submit.prevent>
      <div class="form-group">
        <div class="form-item">
          <label class="form-item-label" for="userName">이름</label>
          <input 
          class="form-item-input" 
          type="text" 
          v-model.trim="userName"
          placeholder="이름을 입력해주세요" />
        </div>
        <div class="form-item">
          <label class="form-item-label" for="fighterNumber">소방관 번호</label>
          <input 
          class="form-item-input" 
          v-model.trim="fighterNumber"
          type="text"
          placeholder="소방관 번호 입력(7자리)" />
        </div>
        <div class="form-item">
          <label class="form-item-label">소속</label>
          <div class="form-item-static">{{ firestation }}</div>
        </div>
        <div class="form-item">
          <label class="form-item-label">담당 업무</label>
          <div class="form-item-static">{{ duty }}</div>
        </div>
      </div>
      <div class="button-group">
        <p class="error-msg">{{ errorMsg }}</p>
        <button v-if="!isVerified" class="signup-button" @click="checkFirefighter">본인 확인</button>
        <button v-if="isVerified" class="signup-button" type="button" @click="signUp">직원 등록</button>
      </div>
    </form>
  </div>
</template>

<script setup>
import { useUserStore } from '@/stores/user';
import { ref } from 'vue';

const store = useUserStore();
const userName = ref('');
const fighterNumber = ref('');
const duty = ref('');
const firestation = ref('');
const errorMsg = ref('');
const isVerified = ref('');

const checkFirefighter =  () => {
  const payload = {
    name: userName.value,
    number: fighterNumber.value,
  }

  const refs = {
    duty, firestation, errorMsg, isVerified
  }

  store.checkFireFighter(payload, refs)
}

const signUp = () => {
  const payload = {
    name: userName.value,
    number: fighterNumber.value,
  }
  
  store.signUp(payload)
}
</script>

<style scoped>
.container {
  width: 100%;
  padding-top: 20px;
  display: flex;
  flex-direction: column;
}

.signup-header {
  margin-left: 5%;
}

.signup-title {
  color: #c2191a;
}

.signup-subtitle {
  color: black;
  font-size: 16px;
  font-weight: 600;
  margin-top: 10px;
}

.signup-form {
  width: 60%;
  max-width: 1000px;
  background: white;
  border-radius: 15px;
  border: 1px solid #ccc;
  padding: 40px;
  box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
  margin: 30px auto;
}

.form-group {
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
  gap: 20px;
}

.form-item {
  margin-bottom: 10px;
  display: flex;
  flex-direction: column;
  box-sizing: border-box;
}

.form-item-label {
  font-size: 24px;
  font-weight: 600;
  color: black;
  margin-bottom: 8px;
}

.form-item-input {
  width: 100%;
  height: 60px;
  box-sizing: border-box;
  margin-top: 10px;
  padding: 10px;
  border-radius: 10px;
  border: 1px solid #ccc;
  font-size: 16px;
  font-weight: 400;
  color: #333;
  outline: none;
  transition: border-color 0.3s;
}

.form-item-input::placeholder {
  color: #b1b1b1;
}

.form-item-input:focus {
  border-color: #c2191a;
}

.form-item-static {
  padding: 5px;
  margin-bottom: 10px;
  font-size: 16px;
  font-weight: 400;
  color: #333;
}

.button-group {
  display: flex;
  flex-direction: column;
  margin-right: auto;
  margin-top: 20px;
}

.error-msg {
  align-self: flex-end;
  color: #FF2222;
}

.signup-button {
  align-self: flex-end;
  width: 30%;
  max-width: 200px;
  height: 50px;
  background: #454545;
  border-radius: 15px;
  color: white;
  font-size: 17px;
  font-weight: 500;
  text-align: center;
  cursor: pointer;
  border: none;
  transition: background-color 0.3s;
}

.signup-button:hover {
  background: #333;
}

@media (max-width: 768px) {
  .signup-title {
    font-size: 28px;
  }

  .signup-subtitle {
    font-size: 14px;
  }

  .signup-form {
    width: 80%;
    padding: 30px;
  }
}

@media (max-width: 480px) {
  .signup-title {
    font-size: 24px;
  }

  .signup-subtitle {
    font-size: 12px;
  }

  .signup-button {
    font-size: 20px;
  }
}
</style>